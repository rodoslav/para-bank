import QRCode from 'qrcode';

/**
 * Renders a QR code inside a container element.
 * @param {HTMLElement} container - The element to render the QR code into.
 * @param {string} text - The text to encode in the QR code.
 * @param {object} [options] - Options for QR code generation.
 */
export function render(container, text, options = {}) {
    try {
        const defaultOptions = {
            width: container.clientWidth || 180, // Use container width or default
            height: container.clientHeight || 180, // Use container height or default
            colorDark : "#000000",
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.M // Medium correction level
        };
        const finalOptions = { ...defaultOptions, ...options };

        container.innerHTML = ''; // Clear previous content
        const qr = new QRCode(container, finalOptions);
        qr.makeCode(text);
    } catch (error) {
        console.error("Failed to generate QR code:", error);
        container.innerHTML = '<p style="color: red; font-size: 0.8rem;">Error generating QR code.</p>';
    }
}