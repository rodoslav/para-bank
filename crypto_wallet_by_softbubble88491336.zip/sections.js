export async function loadSection(name) {
  const app = document.getElementById('app');
  const module = await import(`./sections/${name}.js`);
  app.innerHTML = '';
  app.appendChild(module.render());
}

