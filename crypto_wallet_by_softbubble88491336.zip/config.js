export const config = {
  theme: "light", // or "dark"
  notifications: true,
  walletBackupEnabled: false,
};

