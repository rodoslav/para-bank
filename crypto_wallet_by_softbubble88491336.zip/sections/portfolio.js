export function render() {
  const container = document.createElement('div');
  container.innerHTML = `
    <h2>Portfolio</h2>
    <div class="card">
      <table>
        <thead><tr><th>Crypto</th><th>Amount</th><th>Value</th></tr></thead>
        <tbody id="portfolio-table">
          <!-- Rows will be added dynamically -->
        </tbody>
      </table>
    </div>
    <button id="add-crypto" style="width: 100%;">Add Cryptocurrency</button>
  `;

  const tbody = container.querySelector('#portfolio-table');
  const sampleData = [
    { name: 'Bitcoin', symbol: 'BTC', amount: 0.5, price: 65000 },
    { name: 'Ethereum', symbol: 'ETH', amount: 2, price: 3500 },
    { name: 'Solana', symbol: 'SOL', amount: 15, price: 150 },
  ];
  tbody.innerHTML = ''; // Clear previous content if any
  sampleData.forEach(asset => {
    const row = document.createElement('tr');
    const value = (asset.amount * asset.price).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
    const price = asset.price.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
    row.innerHTML = `
      <td>
        <div>${asset.name}</div>
        <div style="font-size: 0.8rem; color: var(--text-secondary);">${asset.symbol} - ${price}</div>
      </td>
      <td style="text-align: right;">
         <div>${asset.amount} ${asset.symbol}</div>
         <div style="font-size: 0.8rem; color: var(--text-secondary);">${value}</div>
      </td>
      <td style="text-align: right;">${value}</td>`;
    tbody.appendChild(row);
  });

  // Remove the third column header as value is now combined under amount for mobile view
  const headerRow = container.querySelector('thead tr');
   if (headerRow) {
       const headers = headerRow.querySelectorAll('th');
       if(headers.length > 2) {
           headers[1].style.textAlign = 'right'; // Align amount header right
           headers[2].remove(); // Remove original "Value" header
           // Optionally adjust Amount header text
           // headers[1].textContent = 'Holdings';
       }
   }
   // Adjust row data to match new header structure (removing the third td)
   tbody.querySelectorAll('tr').forEach(row => {
       const cells = row.querySelectorAll('td');
       if (cells.length > 2) {
           cells[2].remove();
           cells[1].style.textAlign = 'right'; // Ensure amount cell is right-aligned
       }
   });


  return container;
}