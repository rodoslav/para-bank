import { render as renderQR } from '../utils/qr.js'; // Import a utility to generate QR codes

// Function to render transactions (to easily re-render on filter change)
function renderTransactions(filter = 'all') {
    const txList = document.querySelector('#app #tx-list');
    if (!txList) {
      console.warn("Transaction list element not found for rendering.");
      return; // Exit if the element isn't found in the current view
    }
    txList.innerHTML = ''; // Clear previous entries
    const sampleTxs = [
        { type: 'in', amount: 0.1, asset: 'BTC', date: '2024-06-15', status: 'Completed', address: 'bc1...' },
        { type: 'out', amount: 0.05, asset: 'ETH', date: '2024-06-14', status: 'Pending', address: '0x123...' },
        { type: 'in', amount: 150.5, asset: 'USDC', date: '2024-06-13', status: 'Completed', address: '0xabc...' },
        { type: 'out', amount: 10, asset: 'SOL', date: '2024-06-12', status: 'Failed', address: 'SoL...' },
    ];
    const filteredTxs = sampleTxs.filter(tx => filter === 'all' || tx.type === filter);

    if (filteredTxs.length === 0) {
        txList.innerHTML = '<li style="text-align: center; color: var(--text-secondary);">No transactions found.</li>';
        return;
    }

    filteredTxs.forEach(tx => {
        const li = document.createElement('li');
        li.style.display = 'flex';
        li.style.justifyContent = 'space-between';
        li.style.alignItems = 'center';
        li.style.padding = '0.75rem 0'; // Adjust padding
        const sign = tx.type === 'in' ? '+' : '-';
        const color = tx.type === 'in' ? 'var(--accent)' : 'var(--text)'; // Use accent for incoming

        li.innerHTML = `
          <div style="display: flex; align-items: center; gap: 0.75rem;">
             <!-- Placeholder Icon -->
             <div style="width: 32px; height: 32px; background-color: var(--border-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: ${color};">
               ${tx.asset.substring(0,1)}
             </div>
             <div>
                <div style="font-weight: 500;">${tx.asset} ${tx.type === 'in' ? 'Received' : 'Sent'}</div>
                <div style="font-size: 0.8rem; color: var(--text-secondary);">${new Date(tx.date).toLocaleDateString()} - ${tx.status}</div>
             </div>
          </div>
          <div style="text-align: right;">
            <div style="font-weight: 500; color: ${color};">${sign}${tx.amount} ${tx.asset}</div>
             <!-- Add placeholder USD value conversion -->
             <div style="font-size: 0.8rem; color: var(--text-secondary);">$${(tx.amount * (tx.asset === 'BTC' ? 65000 : tx.asset === 'ETH' ? 3500 : tx.asset === 'SOL' ? 150 : 1)).toFixed(2)}</div>
          </div>
        `;
        txList.appendChild(li);
    });
}

export function render() {
  const container = document.createElement('div');
  container.innerHTML = `
    <h2>Transaction History</h2>

    <div class="card">
      <label for="tx-filter" style="margin-bottom: 0.5rem;">Filter:</label>
      <select id="tx-filter" style="margin-bottom: 1rem;">
        <option value="all">All</option>
        <option value="in">Incoming</option>
        <option value="out">Outgoing</option>
      </select>

      <ul id="tx-list" style="padding: 0;">
        <!-- Transactions will be populated here -->
      </ul>
    </div>
  `;

  // Initial render - needs slight delay or different hook if element isn't immediately available
  // Using setTimeout is a simple workaround, MutationObserver or custom events are better
  setTimeout(() => renderTransactions(), 0);

  // Add event listener for filter dropdown
  const filterSelect = container.querySelector('#tx-filter');
  filterSelect.addEventListener('change', (e) => {
      // Ensure renderTransactions targets the list within this specific container instance
      // if elements are recreated, querySelector might need adjustment.
      renderTransactions(e.target.value);
  });

  return container;
}