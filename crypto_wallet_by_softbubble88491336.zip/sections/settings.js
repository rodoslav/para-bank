import { config } from '../config.js';

export function render() {
  const container = document.createElement('div');
  container.innerHTML = `
    <h2>Settings</h2>
    <div class="card">
      <h3>Appearance</h3>
      <label style="display: flex; align-items: center; justify-content: space-between;">
        Theme:
        <select id="theme-select" style="width: auto;">
          <option value="light" ${config.theme === 'light' ? 'selected' : ''}>Light</option>
          <option value="dark" ${config.theme === 'dark' ? 'selected' : ''}>Dark</option>
        </select>
      </label>
    </div>

    <div class="card">
      <h3>Notifications</h3>
       <label style="display: flex; align-items: center; justify-content: space-between;">
          <span>Market Change Alerts</span>
          <input type="checkbox" id="notifications" class="toggle-switch" ${config.notifications ? 'checked' : ''}>
       </label>
    </div>

     <div class="card">
      <h3>Support</h3>
       <button data-section="support" id="support-nav-button" style="width: 100%;">Help & Support</button>
     </div>

     <div class="card">
       <h3>About</h3>
       <p style="color: var(--text-secondary); font-size: 0.9rem;">Crypto Wallet App v1.0.0</p>
       <button style="width: 100%; background-color: var(--text-secondary);">Check for Updates</button>
     </div>
  `;

  const themeSelect = container.querySelector('#theme-select');
  themeSelect.addEventListener('change', (e) => {
    const newTheme = e.target.value;
    document.documentElement.setAttribute('data-theme', newTheme);
    // Ideally, persist this change (e.g., in localStorage and update config object)
    // config.theme = newTheme; // Note: this won't persist across reloads without more logic
    console.log(`Theme changed to ${newTheme}. Config persistence not implemented.`);
  });

    // Add basic toggle switch styling
   container.querySelectorAll('.toggle-switch').forEach(el => {
       el.style.appearance = 'none';
       el.style.width = '40px';
       el.style.height = '20px';
       el.style.backgroundColor = 'var(--border-color)';
       el.style.borderRadius = '10px';
       el.style.position = 'relative';
       el.style.cursor = 'pointer';
   });

   // Add navigation for the support button within settings
    const supportButton = container.querySelector('#support-nav-button');
    if (supportButton) {
        supportButton.addEventListener('click', () => {
            // Need access to the main navigation handler function
            // This demonstrates a limitation of section-based rendering without a shared event bus or framework
            // For now, manually trigger a click on the main nav button (if available)
             const mainSupportNav = document.querySelector('nav button[data-section="support"]');
             if (mainSupportNav) {
                 mainSupportNav.click();
             } else {
                 // Fallback if main nav isn't present/structured as expected
                 import('sections').then(({ loadSection }) => {
                    loadSection('support');
                    // Manually update active state if possible
                     document.querySelectorAll('nav button').forEach(btn => {
                        btn.classList.toggle('active', btn.dataset.section === 'support');
                     });
                 });
             }
        });
    }


  return container;
}