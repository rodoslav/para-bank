// New file: sections/receive.js
import { render as renderQR } from '../utils/qr.js';

export function render() {
  const container = document.createElement('div');
  // Placeholder user address (replace with actual logic, perhaps based on selected asset)
  const userAddress = "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"; // Example BTC address

  container.innerHTML = `
    <h2>Receive Crypto</h2>

    <div class="card" style="text-align: center;">
      <label for="receive-asset">Asset:</label>
       <select id="receive-asset" style="margin-bottom: 1rem; width: auto;">
          <option value="BTC">Bitcoin (BTC)</option>
          <option value="ETH">Ethereum (ETH)</option>
          <option value="SOL">Solana (SOL)</option>
          <option value="USDC">USD Coin (USDC)</option>
          <!-- Add other owned assets dynamically -->
        </select>


      <p style="color: var(--text-secondary); margin-bottom: 1rem;">Share your address or QR code</p>

      <div id="receive-qr-code" style="margin: 1rem auto; width: 200px; height: 200px; background-color: white; padding: 10px; border-radius: 8px; display: inline-block; line-height: 0;">
        <!-- QR code will be rendered here -->
      </div>

      <div id="receive-address-container" style="margin-top: 1.5rem; word-wrap: break-word;">
        <strong style="display: block; margin-bottom: 0.5rem;">Your Address:</strong>
        <span id="receive-address" style="font-family: monospace; font-size: 0.9rem;">${userAddress}</span>
      </div>

      <button id="copy-address-button" style="width: 100%; margin-top: 1rem;">Copy Address</button>
    </div>
  `;

  // Function to update address and QR based on selection
  const updateReceiveInfo = () => {
    const selectedAsset = container.querySelector('#receive-asset').value;
    // --- Placeholder: In real app, fetch address for selected asset ---
    let address = userAddress; // Default/Example
    if (selectedAsset === 'ETH') address = '0x1234567890abcdef1234567890abcdef12345678';
    else if (selectedAsset === 'SOL') address = 'SoL4n4AddR3ssExamPleSoL4n4AddR3ssExamPle';
    else if (selectedAsset === 'USDC') address = '0xabcdef1234567890abcdef1234567890abcdef12'; // Often same as ETH
    else address = userAddress; // BTC or fallback
    // --- End Placeholder ---

    const addressSpan = container.querySelector('#receive-address');
    addressSpan.textContent = address;

    const qrContainer = container.querySelector('#receive-qr-code');
    // Use a format like "bitcoin:address?amount=..." if desired, otherwise just address
    renderQR(qrContainer, address); // Re-render QR code for the new address
  };


  // Initial render of QR code
  const qrContainer = container.querySelector('#receive-qr-code');
  if (qrContainer) {
    updateReceiveInfo(); // Render initial QR/Address
  } else {
      console.error("QR container not found");
  }

  // Add event listener for asset selection change
  const assetSelect = container.querySelector('#receive-asset');
  assetSelect.addEventListener('change', updateReceiveInfo);


  // Add event listener for copy button
  container.querySelector('#copy-address-button').addEventListener('click', () => {
      const currentAddress = container.querySelector('#receive-address').textContent;
      navigator.clipboard.writeText(currentAddress).then(() => {
          alert('Address copied to clipboard!');
      }).catch(err => {
          console.error('Failed to copy address: ', err);
          alert('Failed to copy address.');
      });
  });


  return container;
}