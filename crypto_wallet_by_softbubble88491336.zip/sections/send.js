// New file: sections/send.js

export function render() {
  const container = document.createElement('div');
  container.innerHTML = `
    <h2>Send Crypto</h2>

    <div class="card">
      <form id="send-form">
        <label for="send-asset">Asset:</label>
        <select id="send-asset" required>
          <option value="BTC">Bitcoin (BTC)</option>
          <option value="ETH">Ethereum (ETH)</option>
          <option value="SOL">Solana (SOL)</option>
          <option value="USDC">USD Coin (USDC)</option>
          <!-- Add other owned assets dynamically -->
        </select>

        <label for="send-address">Recipient Address:</label>
        <div style="display: flex; gap: 0.5rem; align-items: center;">
             <input type="text" id="send-address" placeholder="Enter address or scan QR" required style="flex-grow: 1; margin-top: 0;">
             <button type="button" id="scan-qr-button" style="margin-top: 0; padding: 0.6rem; line-height: 1;" aria-label="Scan QR Code">
                 <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M0 .5A.5.5 0 0 1 .5 0h3a.5.5 0 0 1 0 1H1v2.5a.5.5 0 0 1-1 0v-3Zm12 0a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-1 0V1h-2.5a.5.5 0 0 1 0-1ZM.5 12a.5.5 0 0 1 0 1H3v2.5a.5.5 0 0 1 1 0v-3a.5.5 0 0 1-.5-.5h-3Zm15 0a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1 0-1H15v-2.5a.5.5 0 0 1 .5-.5ZM4 4h1v1H4V4Zm2 0h1v1H6V4Zm2 0h1v1H8V4Zm2 0h1v1h-1V4Zm2 0h1v1h-1V4ZM4 6h1v1H4V6Zm2 0h1v1H6V6Zm2 0h1v1H8V6Zm2 0h1v1h-1V6Zm2 0h1v1h-1V6ZM4 8h1v1H4V8Zm2 0h1v1H6V8Zm2 0h1v1H8V8Zm2 0h1v1h-1V8Zm2 0h1v1h-1V8ZM4 10h1v1H4v-1Zm2 0h1v1H6v-1Zm2 0h1v1H8v-1Zm2 0h1v1h-1v-1Zm2 0h1v1h-1v-1Z"/>
                    <path d="M3 1a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V1Zm9 0a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1V1ZM3 11a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1Z"/>
                 </svg>
             </button>
        </div>


        <label for="send-amount">Amount:</label>
        <input type="number" id="send-amount" placeholder="0.00" step="any" required>
         {/* Consider adding 'Max' button here */}

        <label for="send-fee">Network Fee:</label>
        <div id="send-fee" style="margin-bottom: 1rem; color: var(--text-secondary);">Calculating...</div> {/* Placeholder for fee display */}


        <button type="submit" style="width: 100%; margin-top: 1rem;">Confirm Send</button>
      </form>
    </div>
  `;

    container.querySelector('#send-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const asset = container.querySelector('#send-asset').value;
        const address = container.querySelector('#send-address').value;
        const amount = container.querySelector('#send-amount').value;
        // Placeholder for actual send logic
        alert(`Initiating send (DEMO):\nAsset: ${asset}\nAmount: ${amount}\nTo: ${address}`);
        // Optionally, navigate away or clear form after simulated send
        // e.target.reset(); // Clear the form
    });

     container.querySelector('#scan-qr-button').addEventListener('click', () => {
         // Placeholder for QR code scanning functionality
         alert('QR Code scanning not implemented in this demo.');
         // In a real app, this would trigger camera access and QR decoding,
         // then populate the #send-address field.
     });

     // Simulate fee calculation
     setTimeout(() => {
         const feeElement = container.querySelector('#send-fee');
         if (feeElement) {
             feeElement.textContent = `~$0.50 (0.00001 BTC)`; // Example fee
         }
     }, 1000);


  return container;
}
