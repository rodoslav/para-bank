export function render() {
  const container = document.createElement('div');
  container.innerHTML = `
    <h2>Support</h2>

    <div class="card">
      <h3>Frequently Asked Questions</h3>
      <ul>
        <li>How to reset password?</li>
        <li>How to backup wallet?</li>
        <li>What to do if I lose access?</li>
        <li>Are my funds secure?</li>
      </ul>
    </div>

    <div class="card">
      <h3>Contact Us</h3>
      <form id="contact-form">
        <label for="contact-email">Your Email:</label>
        <input type="email" id="contact-email" required>

        <label for="contact-message" style="margin-top: 1rem;">Message:</label>
        <textarea id="contact-message" required></textarea>

        <button type="submit" style="width: 100%;">Send Message</button>
      </form>
    </div>
  `;
  const form = container.querySelector('#contact-form');
  form.addEventListener('submit', e => {
    e.preventDefault();
    // Basic alert, replace with actual submission logic
    alert('Message sent! (Not really, this is a demo)');
    form.reset();
  });
  return container;
}

