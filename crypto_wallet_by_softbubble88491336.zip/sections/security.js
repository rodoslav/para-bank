export function render() {
  const container = document.createElement('div');
  container.innerHTML = `
    <h2>Security</h2>
    <div class="card">
      <h3>Authentication & Backup</h3>
      <label style="display: flex; align-items: center; justify-content: space-between; padding: 0.75rem 0;">
        <span>Enable 2FA</span>
        <input type="checkbox" id="2fa" class="toggle-switch">
      </label>
       <div style="border-bottom: 1px solid var(--border-color);"></div>
      <label style="display: flex; align-items: center; justify-content: space-between; padding: 0.75rem 0;">
        <span>Backup Wallet</span>
         <input type="checkbox" id="backup" class="toggle-switch">
      </label>
       <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 0.5rem;">Ensure you store your backup securely.</div>
    </div>
     <button style="width: 100%; margin-top: 1rem;">Change Password</button>
  `;
   // Add basic toggle switch styling (needs more CSS for a proper look)
   container.querySelectorAll('.toggle-switch').forEach(el => {
       el.style.appearance = 'none'; // Consider using a library or more CSS for better toggles
       el.style.width = '40px';
       el.style.height = '20px';
       el.style.backgroundColor = 'var(--border-color)';
       el.style.borderRadius = '10px';
       el.style.position = 'relative';
       el.style.cursor = 'pointer';
   });

  return container;
}