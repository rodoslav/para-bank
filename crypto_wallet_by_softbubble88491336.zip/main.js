import { loadSection } from 'sections';
import { config } from 'config';

const navButtons = document.querySelectorAll('nav button');
const appContainer = document.getElementById('app');

function setActiveNav(section) {
  navButtons.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.section === section);
  });
}

function handleNavigation(section) {
  if (!section) return;
  setActiveNav(section);
  loadSection(section).catch(err => {
    console.error(`Failed to load section: ${section}`, err);
    appContainer.innerHTML = `<div class="card">Error loading section: ${section}</div>`;
  });
}

// Add event listeners to nav buttons
navButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    const section = btn.dataset.section;
    handleNavigation(section);
  });
});

// Apply initial theme
document.documentElement.setAttribute('data-theme', config.theme || 'light');

// Load default section
const defaultSection = 'dashboard';
handleNavigation(defaultSection);